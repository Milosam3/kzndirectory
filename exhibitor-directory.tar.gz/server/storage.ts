import { type Exhibitor, type InsertExhibitor } from "@shared/schema";
import { randomUUID } from "crypto";
import { readFileSync, writeFileSync, existsSync } from "fs";
import { join } from "path";

export interface IStorage {
  getExhibitors(): Promise<Exhibitor[]>;
  getExhibitor(id: string): Promise<Exhibitor | undefined>;
  createExhibitor(exhibitor: InsertExhibitor): Promise<Exhibitor>;
  createExhibitors(exhibitors: InsertExhibitor[]): Promise<Exhibitor[]>;
  clearExhibitors(): Promise<void>;
  searchExhibitors(searchTerm: string): Promise<Exhibitor[]>;
}

export class MemStorage implements IStorage {
  private exhibitors: Map<string, Exhibitor>;
  private dataFile: string;

  constructor() {
    this.exhibitors = new Map();
    this.dataFile = join(process.cwd(), 'exhibitors-data.json');
    this.loadData();
  }

  private loadData() {
    try {
      if (existsSync(this.dataFile)) {
        const data = readFileSync(this.dataFile, 'utf-8');
        const exhibitors: Exhibitor[] = JSON.parse(data);
        exhibitors.forEach(exhibitor => {
          this.exhibitors.set(exhibitor.id, exhibitor);
        });
        console.log(`Loaded ${exhibitors.length} exhibitors from storage`);
      }
    } catch (error) {
      console.warn('Failed to load exhibitor data:', error);
    }
  }

  private saveData() {
    try {
      const exhibitors = Array.from(this.exhibitors.values());
      writeFileSync(this.dataFile, JSON.stringify(exhibitors, null, 2));
    } catch (error) {
      console.warn('Failed to save exhibitor data:', error);
    }
  }

  async getExhibitors(): Promise<Exhibitor[]> {
    return Array.from(this.exhibitors.values());
  }

  async getExhibitor(id: string): Promise<Exhibitor | undefined> {
    return this.exhibitors.get(id);
  }

  async createExhibitor(insertExhibitor: InsertExhibitor): Promise<Exhibitor> {
    const id = randomUUID();
    const exhibitor: Exhibitor = { 
      ...insertExhibitor, 
      id,
      logoUrl: insertExhibitor.logoUrl || null,
      phone: insertExhibitor.phone || null,
      email: insertExhibitor.email || null,
      website: insertExhibitor.website || null,
      address: insertExhibitor.address || null,
      description: insertExhibitor.description || null
    };
    this.exhibitors.set(id, exhibitor);
    this.saveData();
    return exhibitor;
  }

  async createExhibitors(insertExhibitors: InsertExhibitor[]): Promise<Exhibitor[]> {
    const exhibitors: Exhibitor[] = [];
    for (const insertExhibitor of insertExhibitors) {
      const id = randomUUID();
      const exhibitor: Exhibitor = { 
        ...insertExhibitor, 
        id,
        logoUrl: insertExhibitor.logoUrl || null,
        phone: insertExhibitor.phone || null,
        email: insertExhibitor.email || null,
        website: insertExhibitor.website || null,
        address: insertExhibitor.address || null,
        description: insertExhibitor.description || null
      };
      this.exhibitors.set(id, exhibitor);
      exhibitors.push(exhibitor);
    }
    this.saveData();
    return exhibitors;
  }

  async clearExhibitors(): Promise<void> {
    this.exhibitors.clear();
    this.saveData();
  }

  async searchExhibitors(searchTerm: string): Promise<Exhibitor[]> {
    const allExhibitors = Array.from(this.exhibitors.values());
    if (!searchTerm.trim()) {
      return allExhibitors;
    }
    
    const term = searchTerm.toLowerCase();
    return allExhibitors.filter(exhibitor =>
      exhibitor.name.toLowerCase().includes(term)
    );
  }
}

export const storage = new MemStorage();
