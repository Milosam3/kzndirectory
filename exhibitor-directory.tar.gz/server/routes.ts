import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertExhibitorSchema, csvUploadSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all exhibitors
  app.get("/api/exhibitors", async (req, res) => {
    try {
      // Add cache-busting headers
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      
      const exhibitors = await storage.getExhibitors();
      res.json(exhibitors);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch exhibitors" });
    }
  });

  // Search exhibitors
  app.get("/api/exhibitors/search", async (req, res) => {
    try {
      // Add cache-busting headers
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      
      const { q } = req.query;
      const searchTerm = typeof q === "string" ? q : "";
      const exhibitors = await storage.searchExhibitors(searchTerm);
      res.json(exhibitors);
    } catch (error) {
      res.status(500).json({ message: "Failed to search exhibitors" });
    }
  });

  // Upload CSV data
  app.post("/api/exhibitors/upload", async (req, res) => {
    try {
      const { file } = csvUploadSchema.parse(req.body);
      
      // Parse CSV content
      const lines = file.split('\n').filter(line => line.trim());
      if (lines.length < 2) {
        return res.status(400).json({ message: "CSV file must contain header and at least one data row" });
      }

      // Parse header
      const headerLine = lines[0];
      const header = headerLine.split(',').map(h => h.trim().replace(/"/g, ''));
      
      const exhibitorData: any[] = [];

      for (let i = 1; i < lines.length; i++) {
        const line = lines[i];
        // Simple CSV parsing - split by comma but handle quoted values
        const values: string[] = [];
        let currentValue = '';
        let inQuotes = false;
        
        for (let j = 0; j < line.length; j++) {
          const char = line[j];
          if (char === '"') {
            inQuotes = !inQuotes;
          } else if (char === ',' && !inQuotes) {
            values.push(currentValue.trim());
            currentValue = '';
          } else {
            currentValue += char;
          }
        }
        values.push(currentValue.trim()); // Add the last value

        if (values.length >= 3) {
          const exhibitor = {
            name: values[0] || '',
            profileUrl: values[1] || '',
            logoUrl: values[2] || '',
            phone: values[3] || '',
            email: values[4] || '',
            website: values[5] || '',
            address: values[6] || '',
            description: values[7] || ''
          };

          // Validate required fields
          if (exhibitor.name && exhibitor.profileUrl) {
            exhibitorData.push(exhibitor);
          }
        }
      }

      if (exhibitorData.length === 0) {
        return res.status(400).json({ message: "No valid exhibitor data found in CSV" });
      }

      // Clear existing data and add new
      await storage.clearExhibitors();
      const exhibitors = await storage.createExhibitors(exhibitorData);

      res.json({ 
        message: "CSV uploaded successfully", 
        count: exhibitors.length,
        exhibitors 
      });
    } catch (error) {
      console.error("CSV upload error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid request data" });
      }
      res.status(500).json({ message: "Failed to process CSV file" });
    }
  });

  // Clear all exhibitors
  app.delete("/api/exhibitors", async (req, res) => {
    try {
      await storage.clearExhibitors();
      res.json({ message: "All exhibitors cleared" });
    } catch (error) {
      res.status(500).json({ message: "Failed to clear exhibitors" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
