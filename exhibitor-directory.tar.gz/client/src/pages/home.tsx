import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Exhibitor } from "@shared/schema";
import { FileUpload } from "@/components/file-upload";
import { SearchFilters } from "@/components/search-filters";
import { ExhibitorTable } from "@/components/exhibitor-table";
import { StatsSection } from "@/components/stats-section";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Download } from "lucide-react";
import { downloadCSV } from "@/lib/csv-utils";

export default function Home() {
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  const { data: exhibitors = [], isLoading } = useQuery<Exhibitor[]>({
    queryKey: ['/api/exhibitors', 'search', { q: searchTerm }],
    queryFn: async () => {
      const response = await fetch(`/api/exhibitors/search?q=${encodeURIComponent(searchTerm)}`);
      if (!response.ok) {
        throw new Error('Failed to fetch exhibitors');
      }
      return response.json();
    },
  });

  const { data: allExhibitors = [] } = useQuery<Exhibitor[]>({
    queryKey: ['/api/exhibitors'],
    queryFn: async () => {
      const response = await fetch('/api/exhibitors');
      if (!response.ok) {
        throw new Error('Failed to fetch exhibitors');
      }
      return response.json();
    },
  });

  const handleExport = () => {
    try {
      if (exhibitors.length === 0) {
        toast({
          title: "No data to export",
          description: "Please upload exhibitor data first or adjust your search.",
          variant: "destructive",
        });
        return;
      }

      const filename = searchTerm 
        ? `exhibitors_search_${searchTerm.replace(/[^a-z0-9]/gi, '_')}.csv`
        : 'exhibitors.csv';
      
      downloadCSV(exhibitors, filename);
      
      toast({
        title: "Export successful!",
        description: `Downloaded ${exhibitors.length} exhibitor records.`,
      });
    } catch (error) {
      toast({
        title: "Export failed",
        description: "Failed to download CSV file",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-semibold text-gray-900">Exhibitor Data Manager</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                onClick={handleExport}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors"
              >
                <Download className="mr-2 h-4 w-4" />
                Export CSV
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* File Upload */}
        <div className="mb-8">
          <FileUpload />
        </div>

        {/* Search and Filters */}
        <div className="mb-6">
          <SearchFilters
            searchTerm={searchTerm}
            onSearchChange={setSearchTerm}
            filteredCount={exhibitors.length}
            totalCount={allExhibitors.length}
          />
        </div>

        {/* Exhibitor Table */}
        <ExhibitorTable
          exhibitors={exhibitors}
          isLoading={isLoading}
        />

        {/* Stats Section */}
        <StatsSection
          exhibitors={allExhibitors}
          filteredCount={exhibitors.length}
        />
      </main>
    </div>
  );
}
