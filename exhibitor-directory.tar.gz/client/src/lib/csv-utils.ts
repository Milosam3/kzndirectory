import { Exhibitor } from "@shared/schema";

export function downloadCSV(data: Exhibitor[], filename: string = "exhibitors.csv") {
  if (data.length === 0) {
    throw new Error("No data to export");
  }

  const headers = ["Name", "Profile URL", "Logo URL", "Phone", "Email", "Website", "Address", "Description"];
  const csvContent = [
    headers.join(","),
    ...data.map(exhibitor => [
      `"${exhibitor.name}"`,
      `"${exhibitor.profileUrl}"`,
      `"${exhibitor.logoUrl || ""}"`,
      `"${exhibitor.phone || ""}"`,
      `"${exhibitor.email || ""}"`,
      `"${exhibitor.website || ""}"`,
      `"${exhibitor.address || ""}"`,
      `"${exhibitor.description || ""}"`
    ].join(","))
  ].join("\n");

  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", filename);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}

export function parseCSVFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      resolve(content);
    };
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsText(file);
  });
}
