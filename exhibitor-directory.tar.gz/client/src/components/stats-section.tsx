import { Exhibitor } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Building, Image, Link, Search } from "lucide-react";

interface StatsSectionProps {
  exhibitors: Exhibitor[];
  filteredCount: number;
}

export function StatsSection({ exhibitors, filteredCount }: StatsSectionProps) {
  const totalExhibitors = exhibitors.length;
  const exhibitorsWithLogos = exhibitors.filter(e => e.logoUrl && e.logoUrl.trim() !== '').length;
  const exhibitorsWithProfiles = exhibitors.filter(e => e.profileUrl && e.profileUrl.trim() !== '').length;

  const stats = [
    {
      title: "Total Exhibitors",
      value: totalExhibitors,
      icon: Building,
      color: "text-blue-600"
    },
    {
      title: "With Logos",
      value: exhibitorsWithLogos,
      icon: Image,
      color: "text-green-600"
    },
    {
      title: "Profile Links",
      value: exhibitorsWithProfiles,
      icon: Link,
      color: "text-purple-600"
    },
    {
      title: "Search Results",
      value: filteredCount,
      icon: Search,
      color: "text-orange-600"
    }
  ];

  return (
    <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <Card key={stat.title}>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <stat.icon className={`h-8 w-8 ${stat.color}`} />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">{stat.title}</p>
                <p className="text-2xl font-semibold text-gray-900">{stat.value}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
