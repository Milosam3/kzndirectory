import { Exhibitor } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, Building, MoreVertical, Phone, Mail, Globe, MapPin } from "lucide-react";

interface ExhibitorTableProps {
  exhibitors: Exhibitor[];
  isLoading: boolean;
}

export function ExhibitorTable({ exhibitors, isLoading }: ExhibitorTableProps) {
  const handleProfileClick = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            <span className="ml-3 text-gray-600">Loading exhibitors...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (exhibitors.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center py-12">
            <Building className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No exhibitors found</h3>
            <p className="text-gray-500 mb-6">Upload a CSV file or adjust your search criteria to see exhibitors.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-0">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">Exhibitor Directory</h3>
        </div>

        {/* Desktop Table View */}
        <div className="hidden lg:block overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Company
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Logo
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Contact Info
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Profile
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {exhibitors.map((exhibitor) => (
                <tr key={exhibitor.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{exhibitor.name}</div>
                    {exhibitor.description && (
                      <div className="text-xs text-gray-500 mt-1 max-w-xs truncate">{exhibitor.description}</div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      {exhibitor.logoUrl ? (
                        <img
                          src={exhibitor.logoUrl}
                          alt={`${exhibitor.name} logo`}
                          className="h-10 w-10 rounded-lg object-cover border border-gray-200"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.style.display = 'none';
                            target.nextElementSibling?.classList.remove('hidden');
                          }}
                        />
                      ) : null}
                      <div className={`h-10 w-10 rounded-lg bg-gray-200 flex items-center justify-center border border-gray-200 ${exhibitor.logoUrl ? 'hidden' : ''}`}>
                        <Building className="h-4 w-4 text-gray-400" />
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="space-y-1">
                      {exhibitor.phone && (
                        <div className="flex items-center text-xs text-gray-600">
                          <Phone className="h-3 w-3 mr-1" />
                          <span>{exhibitor.phone}</span>
                        </div>
                      )}
                      {exhibitor.email && (
                        <div className="flex items-center text-xs text-gray-600">
                          <Mail className="h-3 w-3 mr-1" />
                          <span>{exhibitor.email}</span>
                        </div>
                      )}
                      {exhibitor.website && (
                        <div className="flex items-center text-xs text-gray-600">
                          <Globe className="h-3 w-3 mr-1" />
                          <span className="truncate max-w-32">{exhibitor.website}</span>
                        </div>
                      )}
                      {exhibitor.address && (
                        <div className="flex items-center text-xs text-gray-600">
                          <MapPin className="h-3 w-3 mr-1" />
                          <span className="truncate max-w-32">{exhibitor.address}</span>
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <Button
                      variant="link"
                      onClick={() => handleProfileClick(exhibitor.profileUrl)}
                      className="text-blue-600 hover:text-blue-900 text-sm font-medium p-0 h-auto"
                    >
                      View Profile
                      <ExternalLink className="ml-1 h-3 w-3" />
                    </Button>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-600">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile Card View */}
        <div className="lg:hidden divide-y divide-gray-200">
          {exhibitors.map((exhibitor) => (
            <div key={exhibitor.id} className="p-6">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  {exhibitor.logoUrl ? (
                    <img
                      src={exhibitor.logoUrl}
                      alt={`${exhibitor.name} logo`}
                      className="h-12 w-12 rounded-lg object-cover border border-gray-200"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.style.display = 'none';
                        target.nextElementSibling?.classList.remove('hidden');
                      }}
                    />
                  ) : null}
                  <div className={`h-12 w-12 rounded-lg bg-gray-200 flex items-center justify-center border border-gray-200 ${exhibitor.logoUrl ? 'hidden' : ''}`}>
                    <Building className="h-5 w-5 text-gray-400" />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-medium text-gray-900 truncate">
                    {exhibitor.name}
                  </h4>
                  {exhibitor.description && (
                    <p className="text-xs text-gray-500 mt-1 line-clamp-2">{exhibitor.description}</p>
                  )}
                  <div className="mt-2 space-y-1">
                    {exhibitor.phone && (
                      <div className="flex items-center text-xs text-gray-600">
                        <Phone className="h-3 w-3 mr-1" />
                        <span>{exhibitor.phone}</span>
                      </div>
                    )}
                    {exhibitor.email && (
                      <div className="flex items-center text-xs text-gray-600">
                        <Mail className="h-3 w-3 mr-1" />
                        <span>{exhibitor.email}</span>
                      </div>
                    )}
                    {exhibitor.website && (
                      <div className="flex items-center text-xs text-gray-600">
                        <Globe className="h-3 w-3 mr-1" />
                        <span className="truncate">{exhibitor.website}</span>
                      </div>
                    )}
                    {exhibitor.address && (
                      <div className="flex items-center text-xs text-gray-600">
                        <MapPin className="h-3 w-3 mr-1" />
                        <span className="truncate">{exhibitor.address}</span>
                      </div>
                    )}
                  </div>
                  <div className="mt-3 flex items-center space-x-4">
                    <Button
                      variant="link"
                      onClick={() => handleProfileClick(exhibitor.profileUrl)}
                      className="text-blue-600 hover:text-blue-900 text-sm font-medium p-0 h-auto"
                    >
                      View Profile
                      <ExternalLink className="ml-1 h-3 w-3" />
                    </Button>
                    <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-600">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
