import { pgTable, text, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const exhibitors = pgTable("exhibitors", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  profileUrl: text("profile_url").notNull(),
  logoUrl: text("logo_url"),
  phone: text("phone"),
  email: text("email"),
  website: text("website"),
  address: text("address"),
  description: text("description"),
});

export const insertExhibitorSchema = createInsertSchema(exhibitors).omit({
  id: true,
});

export type InsertExhibitor = z.infer<typeof insertExhibitorSchema>;
export type Exhibitor = typeof exhibitors.$inferSelect;

// CSV upload schema
export const csvUploadSchema = z.object({
  file: z.string().min(1, "CSV content is required"),
});

export type CsvUpload = z.infer<typeof csvUploadSchema>;
