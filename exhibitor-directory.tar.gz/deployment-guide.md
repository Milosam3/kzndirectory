# Deployment Guide for KZN Industrial Exhibitor Directory

## Project Overview
This is a full-stack web application for displaying KZN Industrial exhibitor data with contact details, search functionality, and CSV export capabilities.

## Tech Stack
- Frontend: React 18 + TypeScript + Tailwind CSS + shadcn/ui
- Backend: Express.js + TypeScript
- Data: File-based JSON storage
- Build: Vite

## Free Deployment Options

### Option 1: Vercel (Recommended for this project)
Vercel offers excellent support for full-stack applications with serverless functions.

**Steps:**
1. Download your project files
2. Create a GitHub repository and upload your code
3. Connect Vercel to your GitHub account
4. Deploy directly from GitHub

**Configuration needed:**
- Create `vercel.json` configuration file (provided below)
- Ensure build scripts are properly configured

### Option 2: Netlify
Good for static sites with serverless functions.

**Steps:**
1. Build your project locally
2. Upload the `dist` folder to Netlify
3. Configure serverless functions for the backend API

### Option 3: Railway
Offers generous free tier for full-stack applications.

**Steps:**
1. Connect your GitHub repository
2. Railway will auto-detect and deploy your Node.js application
3. Set environment variables if needed

## Files You'll Need

### 1. vercel.json (for Vercel deployment)
```json
{
  "version": 2,
  "builds": [
    {
      "src": "server/index.ts",
      "use": "@vercel/node"
    },
    {
      "src": "client/**/*",
      "use": "@vercel/static-build",
      "config": {
        "distDir": "dist/public"
      }
    }
  ],
  "routes": [
    {
      "src": "/api/(.*)",
      "dest": "server/index.ts"
    },
    {
      "src": "/(.*)",
      "dest": "dist/public/$1"
    }
  ],
  "functions": {
    "server/index.ts": {
      "maxDuration": 30
    }
  }
}
```

### 2. Build Commands
Make sure your package.json has these scripts:
```json
{
  "scripts": {
    "build": "vite build",
    "start": "node dist/index.js",
    "dev": "NODE_ENV=development tsx server/index.ts"
  }
}
```

## Pre-Deployment Checklist

1. ✅ Data persistence is file-based (exhibitors-data.json)
2. ✅ All dependencies are listed in package.json
3. ✅ Build process creates both frontend and backend bundles
4. ✅ Environment variables are handled properly
5. ✅ API routes are properly configured

## Data Considerations

Your exhibitor data is stored in `exhibitors-data.json`. This file contains:
- 127 KZN Industrial exhibitors
- Contact details for first 3 exhibitors (sample data)
- Complete profile URLs and logo URLs

The file-based storage works well for this read-heavy application and will persist across deployments.

## Next Steps

1. **Download Project**: Get all your project files
2. **Choose Platform**: Vercel is recommended for easiest setup
3. **Create Repository**: Upload to GitHub for easy deployment
4. **Deploy**: Follow platform-specific instructions
5. **Test**: Verify all functionality works in production

## Support

If you encounter issues during deployment:
- Check platform-specific logs for errors
- Ensure all file paths are correct
- Verify environment variables are set
- Test API endpoints individually

Your application is well-structured and should deploy smoothly on any of these platforms!